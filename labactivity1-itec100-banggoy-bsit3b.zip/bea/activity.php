<!DOCTYPE html>
<html>
<head>
  <title>SIGN IN</title>
  <link rel="stylesheet" type="text/css" href="login1.css">
</head>
<body>
  <div class="loginbox">
  <h1>LOGIN HERE</h1>
  <form>
    <p>USERNAME</p>
    <input type="text" name="" placeholder="Enter Password">
    <p>PASSWORD</p>
    <input type="password" name="" placeholder="Enter Password">
    <input type="submit" name="" value="login">
  </form>
  </div>
    <div class="button">
      <a href="register.html" class="btn">REGISTER</a>
    </div>
</body>
</html>


