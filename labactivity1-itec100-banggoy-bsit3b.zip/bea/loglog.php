<?php
$link = mysqli_connect("localhost","root","");
mysqli_select_db($link,"bea");

?>


<!DOCTYPE html>
<html>
<head>
  <title>SIGN IN</title>
  <link rel="stylesheet" type="text/css" href="login1.css">
</head>
<body>
  <div class="loginbox">
  <h1>LOGIN HERE</h1>
  <form>
    <p>USERNAME</p>
    <input type="text" name="username" placeholder="Enter Password">
    <p>PASSWORD</p>
    <input type="password" name="password" placeholder="Enter Password">
    <input type="submit" name="login" value="login">
  </form>
  </div>
    <div class="button">
      <a href="register.html" class="btn">REGISTER</a>
    </div>


<?php
if(isset($_GET['login'])){
$u1=$_GET['username'];
$p1=$_GET['password'];
$tb2="SELECT * FROM `admin` WHERE `user` = '".$u1."' and `pass` = '".$p1."'";

if($result=mysqli_query($link,$tb2)){
  $check = mysqli_num_rows($result);
}
if($check>0){
  header("Location: activity.php");
}
else{
  echo '<script>alert("Login Failed")</script>'; 
}
}
?>



</body>
</html>